<?php

/*
* fooStack, CIUnit for CodeIgniter
* Copyright (c) 2008-2009 Clemens Gruenberger
* Released under the MIT license, see:
* http://www.opensource.org/licenses/mit-license.php
*/

$config['ciu_subclass_prefix'] = 'CIU_';

/* End of file config.php */
/* Location ./application/third_party/CIUnit/config/config.php */