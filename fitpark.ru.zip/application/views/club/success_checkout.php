                <table class="success-message">
                    <tr>
                        <td>
                            <h1 class="success-head-message">
                                Ваша заявка принята
                            </h1>
                            <p>
                                Уведомление о выполнении заказа вам придет по электронной почте или вам позвонит любезный оператор и сообщит все детали.
                                А пока вы можете посмотреть другие предложения нашего портала.
                            </p>
                        </td>
                        <td>
                            <img src="/image/rab_upakowshik.jpg" alt="" width="280px" />
                        </td>
                    </tr>
                </table>
            </div>

<script type="text/javascript" src="/js/success.js"></script>
