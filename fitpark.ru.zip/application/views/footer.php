        </section>
<footer>
            <div class="centerSpan">
                <div class="share42init"></div>
                <script type="text/javascript" src="/js/share42/share42.js"></script>
                <script type="text/javascript">share42('http://фитпарк.рф/js/share42/')</script>
            </div>
            <div class="centerSpan">
                <p>Проводник в мир фитнеса «ФитПарк». Фитнес клубы, расписание тренировок, цены абонементов, отзывы.</p>
                <p>Самара фитнес.</p>
                <p>
                   «ФитПарк» 2012-2013. Все права защищены.
                </p>
                <hr/>
            </div>
        </footer>
    </body>
</html>
